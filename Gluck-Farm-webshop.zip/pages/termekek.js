export default function Termekek() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">Termékeink</h1>
      <ul className="list-disc ml-6">
        <li>Füstölt, olajban eltett fürjtojás</li>
        <li>Aszalt gyümölcsök – alma, szilva, körte</li>
        <li>Gyümölcsszörpök, lekvárok</li>
        <li>Házi dióbél, fűszeres húskészítmények</li>
      </ul>
    </div>
  );
}