export default function Kapcsolat() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">Kapcsolat</h1>
      <p>Email: info@gluck-farm.hu</p>
      <p>Telefon: +36 30 123 4567</p>
      <p>Cím: 7728 Somberek, Mohácsi út 1.</p>
    </div>
  );
}