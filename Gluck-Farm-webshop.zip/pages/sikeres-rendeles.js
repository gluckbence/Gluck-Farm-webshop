export default function SikeresRendeles() {
  return (
    <div className="p-6 text-green-600">
      <h1 className="text-3xl font-bold mb-4">Sikeres rendelés!</h1>
      <p>Köszönjük a vásárlást, hamarosan felvesszük Önnel a kapcsolatot.</p>
    </div>
  );
}