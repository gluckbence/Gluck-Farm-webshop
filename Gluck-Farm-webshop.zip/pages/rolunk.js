export default function Rolunk() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">Rólunk</h1>
      <p>Glück Farm – egy családi vállalkozás, ahol szenvedéllyel készítünk füstölt fürjtojást, aszalványokat és házi különlegességeket. Helyi alapanyagból, kézműves módszerekkel dolgozunk.</p>
    </div>
  );
}