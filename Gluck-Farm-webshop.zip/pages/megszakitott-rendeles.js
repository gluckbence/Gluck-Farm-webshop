export default function MegszakitottRendeles() {
  return (
    <div className="p-6 text-red-600">
      <h1 className="text-3xl font-bold mb-4">Rendelés megszakítva</h1>
      <p>A fizetés megszakadt vagy sikertelen volt. Kérjük, próbálja újra!</p>
    </div>
  );
}